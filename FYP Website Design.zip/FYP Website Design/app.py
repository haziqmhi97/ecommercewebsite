print("Hello World...duhh")
print("*"*10)